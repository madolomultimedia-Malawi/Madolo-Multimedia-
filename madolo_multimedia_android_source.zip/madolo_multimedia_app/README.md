# Madolo Multimedia Android App

Flutter source project for the Madolo Multimedia Android application.

## Included in this prototype
- Home, News, Madolo TV, Sports and Account tabs
- Sample article cards and article reading screen
- Premium subscription information (MWK 2,500/month)
- Copyable Airtel Money and TNM Mpamba merchant numbers
- Dark newsroom design with red and green accents

## Important integration status
This is a functional UI prototype, not yet connected to the production Madolo newsroom. The supplied API domain `https://madolomultimedia.com` was not verified as a live API. Live articles, user authentication, premium entitlement checks, automatic mobile-money payment verification, push notifications and TV streaming require working backend endpoints and credentials. Do not publish this prototype as a live paid-news service until those integrations are completed and tested.

## Build a release APK
Install Flutter 3.24 or newer and Android SDK, then run:

```bash
flutter pub get
flutter create --platforms=android .
flutter build apk --release
```

The APK will be created at `build/app/outputs/flutter-apk/app-release.apk`.

## Build on GitHub Actions
1. Create a GitHub repository and upload this project.
2. Push to the `main` branch.
3. Open the repository's Actions tab and run **Build Madolo Android APK**.
4. Download `madolo-multimedia-release-apk` from the workflow artifacts.
