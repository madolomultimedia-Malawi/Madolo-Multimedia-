import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/news_screen.dart';
import 'screens/tv_screen.dart';
import 'screens/sports_screen.dart';
import 'screens/account_screen.dart';

class MadoloColors {
  static const red = Color(0xFFE30613);
  static const green = Color(0xFF2EAB2F);
  static const black = Color(0xFF090909);
  static const darkGrey = Color(0xFF1A1A1A);
}

void main() => runApp(const MadoloApp());

class MadoloApp extends StatelessWidget {
  const MadoloApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Madolo Multimedia', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: MadoloColors.black,
      colorScheme: ColorScheme.fromSeed(seedColor: MadoloColors.red, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(backgroundColor: MadoloColors.black, foregroundColor: Colors.white),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(backgroundColor: MadoloColors.darkGrey)),
    home: const MainNav(),
  );
}

class MainNav extends StatefulWidget {
  const MainNav({super.key});
  @override State<MainNav> createState() => _MainNavState();
}
class _MainNavState extends State<MainNav> {
  int index = 0;
  final screens = const [HomeScreen(), NewsScreen(), TvScreen(), SportsScreen(), AccountScreen()];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('MADOLO MULTIMEDIA', style: TextStyle(color: MadoloColors.red, fontWeight: FontWeight.w900, letterSpacing: .5)),
      actions: [IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('You are all caught up.'))), icon: const Icon(Icons.notifications_none, color: MadoloColors.red))]),
    body: IndexedStack(index: index, children: screens),
    bottomNavigationBar: BottomNavigationBar(currentIndex: index, onTap: (i) => setState(() => index = i), type: BottomNavigationBarType.fixed,
      selectedItemColor: MadoloColors.red, unselectedItemColor: Colors.white60,
      items: const [BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'), BottomNavigationBarItem(icon: Icon(Icons.article), label: 'News'), BottomNavigationBarItem(icon: Icon(Icons.live_tv), label: 'TV'), BottomNavigationBarItem(icon: Icon(Icons.sports_soccer), label: 'Sports'), BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Account')]),
  );
}
