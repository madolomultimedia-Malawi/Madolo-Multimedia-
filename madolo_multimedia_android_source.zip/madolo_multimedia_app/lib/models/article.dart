class Article {
  final String id, title, summary, body, category, publishedAt, author;
  final bool isPremium, isBreaking;
  const Article({required this.id, required this.title, required this.summary, required this.body, required this.category, required this.publishedAt, required this.author, this.isPremium = false, this.isBreaking = false});
}

const demoArticles = <Article>[
 Article(id:'1', title:'Malawi’s development agenda: Key stories shaping the nation', summary:'The latest developments from government, communities and institutions across Malawi.', body:'This is a demonstration story. Connect the Madolo Multimedia newsroom API to publish verified, up-to-date articles in the application.', category:'Malawi', publishedAt:'Latest', author:'Madolo Multimedia', isBreaking:true),
 Article(id:'2', title:'African leaders discuss regional trade and economic cooperation', summary:'Regional developments and decisions shaping the African continent.', body:'This is sample article content. Live article content will be supplied by the central Madolo Multimedia content management system.', category:'Africa', publishedAt:'Today', author:'Madolo Multimedia'),
 Article(id:'3', title:'The stories making headlines around the world', summary:'A roundup of important international developments.', body:'This is sample article content. Live article content will be supplied by the central Madolo Multimedia content management system.', category:'World', publishedAt:'Today', author:'Madolo Multimedia'),
 Article(id:'4', title:'Inside the issues: An in-depth investigative report', summary:'A premium journalism preview for Madolo subscribers.', body:'Subscribe to Madolo Premium to access the full investigative report.', category:'Investigations', publishedAt:'Today', author:'Madolo Investigations Desk', isPremium:true),
 Article(id:'5', title:'Malawi football: Updates, interviews and match analysis', summary:'Follow local football and the Malawi national teams.', body:'This is sample sports content. Live sports coverage will be published by Madolo Multimedia.', category:'Sports', publishedAt:'Today', author:'Madolo Sports Desk'),
];
