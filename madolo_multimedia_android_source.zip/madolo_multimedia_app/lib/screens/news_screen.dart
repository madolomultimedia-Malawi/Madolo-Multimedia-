import 'package:flutter/material.dart';
import '../main.dart';
import '../models/article.dart';
import 'article_screen.dart';

class NewsScreen extends StatefulWidget { const NewsScreen({super.key}); @override State<NewsScreen> createState()=>_NewsScreenState(); }
class _NewsScreenState extends State<NewsScreen> with SingleTickerProviderStateMixin {
 late final TabController controller; final categories=['All','Malawi','Africa','World','Investigations'];
 @override void initState(){super.initState();controller=TabController(length:categories.length,vsync:this);}
 @override void dispose(){controller.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Column(children:[TabBar(controller:controller,isScrollable:true,indicatorColor:MadoloColors.red,labelColor:MadoloColors.red,unselectedLabelColor:Colors.white70,tabs:categories.map((c)=>Tab(text:c)).toList()),Expanded(child:TabBarView(controller:controller,children:categories.map((c){final items=c=='All'?demoArticles:demoArticles.where((a)=>a.category==c).toList();return items.isEmpty?const Center(child:Text('No stories in this section yet.')):ListView.separated(padding:const EdgeInsets.all(12),itemCount:items.length,separatorBuilder:(_,i)=>const Divider(color:Colors.white12),itemBuilder:(context,i){final a=items[i];return ListTile(contentPadding:const EdgeInsets.symmetric(vertical:6),leading:Container(width:76,height:64,color:MadoloColors.darkGrey,child:const Icon(Icons.article,color:Colors.white38)),title:Text(a.title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${a.category} • ${a.publishedAt}'),trailing:a.isPremium?const Icon(Icons.lock,color:Colors.amber):null,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ArticleScreen(article:a))));});}).toList()))]);
}
