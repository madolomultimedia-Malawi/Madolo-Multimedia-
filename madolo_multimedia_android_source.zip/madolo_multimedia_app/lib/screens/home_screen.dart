import 'package:flutter/material.dart';
import '../main.dart';
import '../models/article.dart';
import 'article_screen.dart';
import 'premium_screen.dart';

class HomeScreen extends StatelessWidget {
 const HomeScreen({super.key});
 @override Widget build(BuildContext context) {
  final lead=demoArticles.first;
  return ListView(padding:const EdgeInsets.only(bottom:20), children:[
   Container(color:MadoloColors.red,padding:const EdgeInsets.all(12),child:Text('BREAKING  •  ${lead.title}',style:const TextStyle(fontWeight:FontWeight.bold))),
   InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ArticleScreen(article:lead))), child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(height:205,color:MadoloColors.darkGrey,width:double.infinity,child:const Center(child:Icon(Icons.newspaper,size:70,color:Colors.white24))), Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('TOP STORY',style:TextStyle(color:MadoloColors.red,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(lead.title,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(lead.summary,style:const TextStyle(color:Colors.white70)),const SizedBox(height:8),Text('By ${lead.author} • ${lead.publishedAt}',style:const TextStyle(color:Colors.white54,fontSize:12))]))]),
   Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PremiumScreen())),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(gradient:const LinearGradient(colors:[MadoloColors.red,Color(0xFF780000)]),borderRadius:BorderRadius.circular(8)),child:const Row(children:[Icon(Icons.workspace_premium,size:34),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('MADOLO PREMIUM',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),Text('Unlock exclusive journalism • K2,500/month',style:TextStyle(fontSize:12))])),Icon(Icons.chevron_right)])))),
   const Padding(padding:EdgeInsets.fromLTRB(16,22,16,8),child:Text('LATEST STORIES',style:TextStyle(color:MadoloColors.red,fontWeight:FontWeight.bold,fontSize:18))),
   ...demoArticles.map((a)=>ListTile(leading:Container(width:66,height:58,color:MadoloColors.darkGrey,child:const Icon(Icons.article_outlined)),title:Text(a.title,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${a.category} • ${a.publishedAt}'),trailing:a.isPremium?const Icon(Icons.star,color:Colors.amber):null,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ArticleScreen(article:a)))))
  ]);
 }
}
