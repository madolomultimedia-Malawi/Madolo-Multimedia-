import 'package:flutter/material.dart';
import '../main.dart';
import '../models/article.dart';
import 'premium_screen.dart';

class ArticleScreen extends StatelessWidget {
 final Article article;
 const ArticleScreen({super.key, required this.article});
 @override Widget build(BuildContext context) => Scaffold(
  appBar: AppBar(title: Text(article.category)),
  body: ListView(children:[Container(height:210, color:MadoloColors.darkGrey, child: const Center(child: Icon(Icons.newspaper, size:76, color:Colors.white24))),
   Padding(padding:const EdgeInsets.all(16), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
    if(article.isBreaking) const Chip(label:Text('BREAKING NEWS'), backgroundColor:MadoloColors.red),
    Text(article.title, style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)), const SizedBox(height:10),
    Text('By ${article.author} • ${article.publishedAt}', style:const TextStyle(color:Colors.white54)), const Divider(height:30),
    if(article.isPremium) ...[const Center(child:Icon(Icons.lock, color:Colors.amber,size:48)), const SizedBox(height:12), const Text('This is a Madolo Premium story. Subscribe to continue reading.',textAlign:TextAlign.center), const SizedBox(height:16), Center(child:ElevatedButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PremiumScreen())), child:const Text('View subscription options')))]
    else Text(article.body, style:const TextStyle(fontSize:17,height:1.6)),
    const SizedBox(height:24), OutlinedButton.icon(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Sharing will be available when the article service is connected.'))), icon:const Icon(Icons.share), label:const Text('Share story'))
   ]))]));
}
